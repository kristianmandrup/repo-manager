Repo
----

-	name
-	summary (markdown)
-	description (markdown)
-	owner
-	tags (any string)
	-	authentication
	-	...
-	repo source (github, ...)
-	location (url)

Dev Management
--------------

-	milestones
-	issues
-	build status

Dependencies
------------

-	dependendencies (from dep graph)
-	used by (from dep graph)
