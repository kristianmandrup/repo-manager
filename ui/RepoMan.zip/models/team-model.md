Team
----

-	name
-	summary (markdown)
-	description (markdown)
-	owner (who created team)
-	tags (any string)
	-	authentication
	-	...

Works on
--------

-	repos
-	projects

Consists of
-----------

-	members: Person[]
-	teams: Team[]
