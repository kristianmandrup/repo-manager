Admin: Repos for project
========================

Select repos from a Repo source: github, gitlab, gitorious, bitbucket, codeplane...

### Add new repos

-	List of Repo providers supported
-	For each a (+) Add icon (float right) to add a repo from that provider

### Current project repos

-	List of current repos registered for the project
-	For each repo a (-) Remove icon to remove it
