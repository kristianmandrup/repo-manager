Admin
=====

Projects
--------

-	Add/Remove projects

Project
-------

-	Add/Remove teams
-	Add/Remove team members
-	Add/Remove repos

Repos
-----

-	Add/Remove repos
-	Add/Remove repos: projects (drag/drop)
-	Rate repos

Repo
----

-	Add/Remove teams
-	Add/Remove team members
-	Add/Remove projects
-	Rate repo

CIs
---

-	Add/Remove CIs
-	Add/Remove CIs: repos (drag/drop)

Teams
-----

-	Add/Remove teams
-	Add/Remove teams: projects (drag/drop)
-	Edit team names
-	Edit team tags
-	Rate teams

Team
----

-	Add/Remove projects (drag/drop)
-	Add/Remove team members (drag/drop)
-	Edit team name
-	Edit team tags
-	Rate team

Team members
------------

-	Add/Remove team member (gmail)
-	Add/Remove team member: teams (drag/drop)
-	Add/Remove team member: projects (drag/drop)
-	Edit name
-	Edit tags
-	Rate team member
