Builder
=======

Allows building custom UI for each type of page
