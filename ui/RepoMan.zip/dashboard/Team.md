Team
====

-	Name
-	Tags (designer, backend, testing, sysadmin)
-	Projects team is working on
-	Team members
	-	Activity graph for each member on this project
