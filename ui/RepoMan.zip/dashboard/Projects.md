# Projects

Search: by name, tag, team

- Name + rating stars (1-5) (priority, highest listed first)
- Tags (categories)
- Teams working on each project
- Repos for each project with latest build status (ok, fail, none)
- Mini Activity graph

Mouseover on Project name, shows popup with Project summary.
Mouseover on Repo, shows popup with Repo summary.
Click on Activity graph shows modal with full Activity graph

Using Tags you can filter on Type of project such as "Test" projects etc.