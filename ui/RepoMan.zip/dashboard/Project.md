# Project

- Name + Rating stars (1-5) (priority, highest listed first)

- Teams working on project
  - Team members
    - Activity graph for each member on this project

Project feeds
- Comments

Management
- Issues
- Features
- Milestones

