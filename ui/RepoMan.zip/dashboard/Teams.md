Teams
=====

-	List of all teams
-	Tags for each team (designer, backend, testing, sysadmin)
-	Projects each team are working on
-	Team members
